// register-auth.js - User Registration Page

document.addEventListener('DOMContentLoaded', function() {
    console.log('User registration page loaded');
    
    // DOM Elements
    const registerForm = document.getElementById('userRegisterForm');
    const fullnameInput = document.getElementById('fullname');
    const usernameInput = document.getElementById('username');
    const emailInput = document.getElementById('email');
    const professionSelect = document.getElementById('profession');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const termsCheckbox = document.getElementById('termsCheckbox');
    const registerBtn = document.getElementById('registerBtn');
    
    // Get selected plan
    let selectedPlan = localStorage.getItem('selectedPlan') || 'free';
    
    // Modal elements
    const termsModal = document.getElementById('termsModal');
    const privacyModal = document.getElementById('privacyModal');
    const showTermsLink = document.getElementById('showTermsLink');
    const showPrivacyLink = document.getElementById('showPrivacyLink');
    
    // Modal functions
    window.openTermsModal = function() {
        if (termsModal) termsModal.classList.remove('hidden');
    }
    window.closeTermsModal = function() {
        if (termsModal) termsModal.classList.add('hidden');
    }
    window.openPrivacyModal = function() {
        if (privacyModal) privacyModal.classList.remove('hidden');
    }
    window.closePrivacyModal = function() {
        if (privacyModal) privacyModal.classList.add('hidden');
    }
    
    if (showTermsLink) {
        showTermsLink.addEventListener('click', function(e) {
            e.preventDefault();
            window.openTermsModal();
        });
    }
    if (showPrivacyLink) {
        showPrivacyLink.addEventListener('click', function(e) {
            e.preventDefault();
            window.openPrivacyModal();
        });
    }
    
    window.addEventListener('click', function(e) {
        if (e.target === termsModal) window.closeTermsModal();
        if (e.target === privacyModal) window.closePrivacyModal();
    });
    
    // Helper functions
    function getUsers() {
        const stored = localStorage.getItem('registeredUsers');
        if (stored) return JSON.parse(stored);
        const defaultUsers = [
            { fullname: 'Regular User', username: 'user', email: 'user@lumen.com', password: 'password123', role: 'user', registeredAt: new Date().toISOString() },
            { fullname: 'Administrator', username: 'admin', email: 'admin@lumen.com', password: 'admin123', role: 'admin', registeredAt: new Date().toISOString() }
        ];
        localStorage.setItem('registeredUsers', JSON.stringify(defaultUsers));
        return defaultUsers;
    }
    
    function saveUsers(users) {
        localStorage.setItem('registeredUsers', JSON.stringify(users));
    }
    
    function showMessage(message, type) {
        const existingMsg = document.querySelector('.error-message, .success-message, .warning-message');
        if (existingMsg) existingMsg.remove();
        
        let icon = '';
        if (type === 'error') icon = 'fas fa-exclamation-circle';
        else if (type === 'success') icon = 'fas fa-check-circle';
        else if (type === 'warning') icon = 'fas fa-exclamation-triangle';
        
        const msgDiv = document.createElement('div');
        msgDiv.className = `${type}-message`;
        msgDiv.innerHTML = `<i class="${icon}"></i> ${message}`;
        registerForm.insertBefore(msgDiv, registerForm.firstChild);
        
        setTimeout(() => {
            if (msgDiv) msgDiv.remove();
        }, 4000);
    }
    
    function isValidEmail(email) {
        return /^[^\s@]+@([^\s@]+\.)+[^\s@]+$/.test(email);
    }
    
    function isValidUsername(username) {
        return /^[a-zA-Z0-9_]{3,20}$/.test(username);
    }
    
    function isUsernameTaken(username) {
        return getUsers().some(u => u.username.toLowerCase() === username.toLowerCase());
    }
    
    function isEmailTaken(email) {
        return getUsers().some(u => u.email.toLowerCase() === email.toLowerCase());
    }
    
    function calculatePasswordStrength(password) {
        let strength = 0;
        if (password.length >= 8) strength++;
        if (/[A-Z]/.test(password)) strength++;
        if (/[a-z]/.test(password)) strength++;
        if (/[0-9]/.test(password)) strength++;
        if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength++;
        return strength;
    }
    
    function validateForm() {
        const fullname = fullnameInput.value.trim();
        const username = usernameInput.value.trim();
        const email = emailInput.value.trim();
        const password = passwordInput.value;
        const confirm = confirmPasswordInput.value;
        const terms = termsCheckbox.checked;
        
        let isValid = true;
        if (!fullname) isValid = false;
        else if (!username || !isValidUsername(username) || isUsernameTaken(username)) isValid = false;
        else if (!email || !isValidEmail(email) || isEmailTaken(email)) isValid = false;
        else if (calculatePasswordStrength(password) < 3) isValid = false;
        else if (password !== confirm) isValid = false;
        else if (!terms) isValid = false;
        
        registerBtn.disabled = !isValid;
        return isValid;
    }
    
    // Username availability - REAL TIME
    usernameInput.addEventListener('input', function() {
        const username = usernameInput.value.trim();
        const msgDiv = document.getElementById('usernameMessage');
        
        if (username === '') {
            msgDiv.innerHTML = '';
            msgDiv.className = 'field-message';
        } else if (!isValidUsername(username)) {
            msgDiv.innerHTML = '<i class="fas fa-times-circle"></i> Username must be 3-20 characters (letters, numbers, _ only)';
            msgDiv.className = 'field-message error';
        } else if (isUsernameTaken(username)) {
            msgDiv.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Username already taken';
            msgDiv.className = 'field-message error';
        } else {
            msgDiv.innerHTML = '<i class="fas fa-check-circle"></i> Username available';
            msgDiv.className = 'field-message success';
        }
        validateForm();
    });
    
    // Email validation - REAL TIME
    emailInput.addEventListener('input', function() {
        const email = emailInput.value.trim();
        const msgDiv = document.getElementById('emailMessage');
        
        if (email === '') {
            msgDiv.innerHTML = '';
            msgDiv.className = 'field-message';
        } else if (!isValidEmail(email)) {
            msgDiv.innerHTML = '<i class="fas fa-times-circle"></i> Please enter a valid email address';
            msgDiv.className = 'field-message error';
        } else if (isEmailTaken(email)) {
            msgDiv.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Email already registered';
            msgDiv.className = 'field-message error';
        } else {
            msgDiv.innerHTML = '<i class="fas fa-check-circle"></i> Valid email address';
            msgDiv.className = 'field-message success';
        }
        validateForm();
    });
    
    // Confirm password - REAL TIME
    confirmPasswordInput.addEventListener('input', function() {
        const msgDiv = document.getElementById('confirmMessage');
        
        if (confirmPasswordInput.value === '') {
            msgDiv.innerHTML = '';
        } else if (passwordInput.value !== confirmPasswordInput.value) {
            msgDiv.innerHTML = '<i class="fas fa-times-circle"></i> Passwords do not match';
            msgDiv.style.color = '#f44336';
        } else {
            msgDiv.innerHTML = '<i class="fas fa-check-circle"></i> Passwords match';
            msgDiv.style.color = '#4caf50';
        }
        validateForm();
    });
    
    // Password strength - REAL TIME
    function updateStrengthIndicator() {
        const password = passwordInput.value;
        const strength = calculatePasswordStrength(password);
        const strengthBar = document.getElementById('strengthBar');
        const strengthText = document.getElementById('strengthText');
        const strengthScore = document.getElementById('strengthScore');
        
        let level = '', text = '', scoreText = '';
        
        if (password === '') {
            level = 'weak';
            text = 'Enter a password';
            scoreText = '0/5';
        } else if (strength <= 2) {
            level = 'weak';
            text = 'Weak Password';
            scoreText = `${strength}/5`;
        } else if (strength === 3) {
            level = 'medium';
            text = 'Medium Password';
            scoreText = '3/5';
        } else if (strength === 4) {
            level = 'strong';
            text = 'Strong Password!';
            scoreText = '4/5';
        } else {
            level = 'very-strong';
            text = 'Very Strong Password! Excellent!';
            scoreText = '5/5';
        }
        
        strengthBar.className = `strength-level ${level}`;
        strengthText.className = `strength-text ${level}`;
        strengthText.textContent = text;
        strengthScore.textContent = scoreText;
        
        // Update requirement checkmarks
        const reqLength = document.getElementById('reqLength');
        const reqUppercase = document.getElementById('reqUppercase');
        const reqLowercase = document.getElementById('reqLowercase');
        const reqNumber = document.getElementById('reqNumber');
        const reqSpecial = document.getElementById('reqSpecial');
        
        if (reqLength) {
            reqLength.innerHTML = password.length >= 8 ? '<i class="fas fa-check-circle"></i> At least 8 characters' : '<i class="far fa-circle"></i> At least 8 characters';
            reqLength.className = password.length >= 8 ? 'valid' : 'invalid';
        }
        if (reqUppercase) {
            reqUppercase.innerHTML = /[A-Z]/.test(password) ? '<i class="fas fa-check-circle"></i> At least 1 uppercase letter (A-Z)' : '<i class="far fa-circle"></i> At least 1 uppercase letter (A-Z)';
            reqUppercase.className = /[A-Z]/.test(password) ? 'valid' : 'invalid';
        }
        if (reqLowercase) {
            reqLowercase.innerHTML = /[a-z]/.test(password) ? '<i class="fas fa-check-circle"></i> At least 1 lowercase letter (a-z)' : '<i class="far fa-circle"></i> At least 1 lowercase letter (a-z)';
            reqLowercase.className = /[a-z]/.test(password) ? 'valid' : 'invalid';
        }
        if (reqNumber) {
            reqNumber.innerHTML = /[0-9]/.test(password) ? '<i class="fas fa-check-circle"></i> At least 1 number (0-9)' : '<i class="far fa-circle"></i> At least 1 number (0-9)';
            reqNumber.className = /[0-9]/.test(password) ? 'valid' : 'invalid';
        }
        if (reqSpecial) {
            reqSpecial.innerHTML = /[!@#$%^&*(),.?":{}|<>]/.test(password) ? '<i class="fas fa-check-circle"></i> At least 1 special character (!@#$%^&*)' : '<i class="far fa-circle"></i> At least 1 special character (!@#$%^&*)';
            reqSpecial.className = /[!@#$%^&*(),.?":{}|<>]/.test(password) ? 'valid' : 'invalid';
        }
        
        validateForm();
    }
    
    passwordInput.addEventListener('input', updateStrengthIndicator);
    
    // Other event listeners
    fullnameInput.addEventListener('input', validateForm);
    professionSelect.addEventListener('change', validateForm);
    termsCheckbox.addEventListener('change', validateForm);
    
    // Password toggle
    const togglePasswordBtn = document.getElementById('togglePassword');
    const toggleConfirmBtn = document.getElementById('toggleConfirmPassword');
    let isPasswordVisible = false;
    let isConfirmVisible = false;
    
    if (togglePasswordBtn) {
        togglePasswordBtn.addEventListener('click', () => {
            const monkeySpan = togglePasswordBtn.querySelector('.monkey-icon');
            if (!isPasswordVisible) {
                passwordInput.type = 'text';
                monkeySpan.innerHTML = '🐵';
                isPasswordVisible = true;
            } else {
                passwordInput.type = 'password';
                monkeySpan.innerHTML = '🙈';
                isPasswordVisible = false;
            }
        });
    }
    
    if (toggleConfirmBtn) {
        toggleConfirmBtn.addEventListener('click', () => {
            const monkeySpan = toggleConfirmBtn.querySelector('.monkey-icon');
            if (!isConfirmVisible) {
                confirmPasswordInput.type = 'text';
                monkeySpan.innerHTML = '🐵';
                isConfirmVisible = true;
            } else {
                confirmPasswordInput.type = 'password';
                monkeySpan.innerHTML = '🙈';
                isConfirmVisible = false;
            }
        });
    }
    
    // Form submission
    registerForm.addEventListener('submit', async function(event) {
        event.preventDefault();
        
        const fullname = fullnameInput.value.trim();
        const username = usernameInput.value.trim();
        const email = emailInput.value.trim();
        const password = passwordInput.value;
        const profession = professionSelect ? professionSelect.value : '';
        
        if (!fullname) { showMessage('Please enter your full name', 'error'); return; }
        if (!username) { showMessage('Please enter a username', 'error'); return; }
        if (!email) { showMessage('Please enter your email', 'error'); return; }
        if (!password) { showMessage('Please enter a password', 'error'); return; }
        
        if (calculatePasswordStrength(password) < 3) {
            showMessage('Please create a stronger password', 'error');
            return;
        }
        
        if (password !== confirmPasswordInput.value) {
            showMessage('Passwords do not match', 'error');
            return;
        }
        
        if (!termsCheckbox.checked) {
            showMessage('Please agree to the Terms and Privacy Policy', 'error');
            return;
        }
        
        registerBtn.disabled = true;
        registerBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const currentUsers = getUsers();
        
        if (currentUsers.some(u => u.username.toLowerCase() === username.toLowerCase())) {
            showMessage('Username already taken', 'error');
            registerBtn.disabled = false;
            registerBtn.innerHTML = '<i class="fas fa-user-plus"></i> Create Account';
            return;
        }
        
        if (currentUsers.some(u => u.email.toLowerCase() === email.toLowerCase())) {
            showMessage('Email already registered', 'error');
            registerBtn.disabled = false;
            registerBtn.innerHTML = '<i class="fas fa-user-plus"></i> Create Account';
            return;
        }
        
        // Determine account type based on selected plan
        let finalAccountType = 'free';
        if (selectedPlan === 'free') {
            finalAccountType = 'free';
        } else if (selectedPlan === 'premium') {
            finalAccountType = 'premium';
        } else if (selectedPlan === 'enterprise') {
            finalAccountType = 'enterprise';
        }
        
        const newUser = {
            fullname: fullname, 
            username: username, 
            email: email, 
            password: password,
            profession: profession, 
            accountType: finalAccountType, 
            role: 'user',
            registeredAt: new Date().toISOString()
        };
        
        currentUsers.push(newUser);
        saveUsers(currentUsers);
        
        // Auto login
        localStorage.setItem('user', JSON.stringify({
            username: username, 
            email: email, 
            role: 'user', 
            name: fullname, 
            accountType: finalAccountType
        }));
        
        showMessage('Account created successfully! Redirecting...', 'success');
        
        // Redirect based on selected plan
        setTimeout(() => {
            if (selectedPlan === 'free') {
                window.location.href = 'dashboard.html';
            } else if (selectedPlan === 'premium') {
                window.location.href = `payment.html?plan=premium&email=${encodeURIComponent(email)}&name=${encodeURIComponent(fullname)}`;
            } else if (selectedPlan === 'enterprise') {
                // Add to custom requests for admin
                let customReqs = JSON.parse(localStorage.getItem('customPlanRequests') || '[]');
                customReqs.push({
                    name: fullname,
                    email: email,
                    requestedAt: new Date().toISOString(),
                    status: 'pending'
                });
                localStorage.setItem('customPlanRequests', JSON.stringify(customReqs));
                window.location.href = `contact-creator.html?email=${encodeURIComponent(email)}&name=${encodeURIComponent(fullname)}`;
            } else {
                window.location.href = 'dashboard.html';
            }
        }, 1500);
    });
    
    validateForm();
});