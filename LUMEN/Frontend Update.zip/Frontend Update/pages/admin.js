// admin.js - Admin Page Logic (Complete with error handling)

let currentFilter = 'all';
let currentRequestId = null;
let activityChart = null;

// ========== HELPER FUNCTION WITH ERROR HANDLING ==========
function safeSetInnerText(id, value) {
    const element = document.getElementById(id);
    if (element) {
        element.innerText = value;
    } else {
        console.warn(`Element with id '${id}' not found`);
    }
}

// ========== CHECK ADMIN AUTH ==========
function checkAdminAuth() {
    const user = localStorage.getItem('user');
    if (!user) {
        window.location.href = 'login.html';
        return false;
    }
    const userData = JSON.parse(user);
    if (userData.role !== 'admin') {
        window.location.href = 'dashboard.html';
        return false;
    }
    const userNameDisplay = document.getElementById('userNameDisplay');
    if (userNameDisplay) {
        userNameDisplay.innerText = userData.email.split('@')[0];
    }
    return true;
}

function logout() {
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

// ========== GET DATA ==========
function getUsers() {
    const stored = localStorage.getItem('registeredUsers');
    return stored ? JSON.parse(stored) : [];
}

function getScans() {
    const stored = localStorage.getItem('scanHistory');
    return stored ? JSON.parse(stored) : [];
}

function getRequests() {
    const stored = localStorage.getItem('premiumRequests');
    return stored ? JSON.parse(stored) : [];
}

function getRules() {
    const stored = localStorage.getItem('securityRules');
    return stored ? JSON.parse(stored) : [];
}

function getCustomRequests() {
    const stored = localStorage.getItem('customPlanRequests');
    console.log('Custom requests from storage:', stored);
    return stored ? JSON.parse(stored) : [];
}

// ========== USER STATS ==========
function getUserCounts() {
    const users = getUsers();
    console.log('All users:', users);
    
    const free = users.filter(u => u.accountType === 'free' || !u.accountType).length;
    const premium = users.filter(u => u.accountType === 'premium').length;
    const enterprise = users.filter(u => u.accountType === 'enterprise').length;
    
    console.log('Free count:', free, 'Premium count:', premium, 'Enterprise count:', enterprise);
    
    return { free, premium, enterprise };
}

function filterUsersByType(type) {
    switchToTab('users');
    setTimeout(() => {
        const users = getUsers();
        let filteredUsers = [];
        let filterName = '';
        if (type === 'free') {
            filteredUsers = users.filter(u => u.accountType === 'free' || !u.accountType);
            filterName = 'Free';
        } else if (type === 'premium') {
            filteredUsers = users.filter(u => u.accountType === 'premium');
            filterName = 'Premium';
        } else if (type === 'enterprise') {
            filteredUsers = users.filter(u => u.accountType === 'enterprise');
            filterName = 'Enterprise';
        }
        displayFilteredUsers(filteredUsers, filterName);
    }, 100);
}

function displayFilteredUsers(users, type) {
    const tbody = document.getElementById('usersTableBody');
    if (!tbody) return;
    
    if (users.length === 0) {
        tbody.innerHTML = `</td><td colspan="7" class="no-data">No ${type} users found</td></tr>`;
        return;
    }
    const scans = getScans();
    tbody.innerHTML = users.map((u, i) => `
        <tr>
            <td>${i+1}</td>
            <td>${escapeHtml(u.fullname || 'N/A')}</td>
            <td><i class="fas fa-at"></i> ${escapeHtml(u.username)}</td>
            <td><i class="fas fa-envelope"></i> ${escapeHtml(u.email)}</td>
            <td><span class="status-badge ${u.accountType === 'premium' ? 'resolved' : 'pending'}">${u.accountType || 'free'}</span></td>
            <td>${u.registeredAt ? new Date(u.registeredAt).toLocaleDateString() : 'N/A'}</td>
            <td>${u.role !== 'admin' ? `<button class="action-btn delete" onclick="deleteUser('${u.email}')">Delete</button>` : '<span class="admin-badge">Admin</span>'}</td>
        </tr>
    `).join('');
}

// ========== TAB SWITCHING ==========
function switchToTab(tabName) {
    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
    
    const targetTab = document.getElementById(`${tabName}Tab`);
    if (targetTab) targetTab.classList.add('active');
    
    const activeLink = document.querySelector(`[data-tab="${tabName}"]`);
    if (activeLink) activeLink.classList.add('active');
    
    if (tabName === 'dashboard') loadDashboard();
    else if (tabName === 'requests') loadRequests();
    else if (tabName === 'rules') loadRules();
    else if (tabName === 'users') loadUsers();
    else if (tabName === 'customRequests') loadCustomRequests();
}

// ========== DASHBOARD ==========
function loadDashboard() {
    const users = getUsers();
    const requests = getRequests();
    const scans = getScans();
    const counts = getUserCounts();
    const customReqs = getCustomRequests();
    
    safeSetInnerText('totalUsers', users.length);
    safeSetInnerText('freeUsers', counts.free);
    safeSetInnerText('premiumUsers', counts.premium);
    safeSetInnerText('enterpriseUsers', counts.enterprise);
    safeSetInnerText('totalScans', scans.length);
    safeSetInnerText('pendingRequests', requests.filter(r => r.status === 'pending').length);
    safeSetInnerText('resolvedRequests', requests.filter(r => r.status === 'resolved').length);
    safeSetInnerText('customRequests', customReqs.length);
    
    // Chart
    const ctx = document.getElementById('activityChart');
    if (ctx && scans.length > 0) {
        const last7Days = [];
        for (let i = 6; i >= 0; i--) {
            const d = new Date();
            d.setDate(d.getDate() - i);
            last7Days.push(d.toLocaleDateString());
        }
        const scanCounts = last7Days.map(day => scans.filter(s => new Date(s.timestamp).toLocaleDateString() === day).length);
        if (activityChart) activityChart.destroy();
        activityChart = new Chart(ctx, {
            type: 'line',
            data: { labels: last7Days.map(d => d.substring(5)), datasets: [{ label: 'Scans', data: scanCounts, borderColor: '#06b6d4', fill: true }] },
            options: { responsive: true, maintainAspectRatio: true }
        });
    }
    
    // Recent activity
    const container = document.getElementById('recentActivity');
    if (container) {
        if (requests.length === 0) container.innerHTML = '<div class="no-data">No recent activity</div>';
        else container.innerHTML = requests.slice(-5).reverse().map(r => `
            <div class="recent-item"><div class="recent-icon ${r.status}"><i class="fas ${r.status === 'pending' ? 'fa-clock' : 'fa-check-circle'}"></i></div>
            <div class="recent-details"><div class="recent-text">${r.status === 'pending' ? 'New request from' : 'Resolved for'} ${escapeHtml(r.userId)}</div>
            <div class="recent-time">${new Date(r.timestamp).toLocaleString()}</div></div></div>
        `).join('');
    }
}

// ========== REQUESTS ==========
function loadRequests() {
    let requests = getRequests();
    if (currentFilter !== 'all') requests = requests.filter(r => r.status === currentFilter);
    const tbody = document.getElementById('requestsTableBody');
    if (!tbody) return;
    
    if (requests.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="no-data">No requests found</td></table>';
        return;
    }
    tbody.innerHTML = requests.map(r => `
        <tr>
            <td>#${r.id}</td>
            <td>${escapeHtml(r.userId)}</td>
            <td style="max-width:300px;">${escapeHtml(r.problem.substring(0, 60))}${r.problem.length > 60 ? '...' : ''}</td>
            <td><span class="status-badge ${r.status}">${r.status}</span></td>
            <td>${new Date(r.timestamp).toLocaleDateString()}</td>
            <td>${r.solution ? `<button class="action-btn" onclick="viewSolution('${r.id}')">View</button>` : 'Pending'}</td>
            <td>${!r.solution ? `<button class="action-btn" onclick="openSolutionModal('${r.id}')">Provide Solution</button>` : 'Completed'}</td>
        </tr>
    `).join('');
}

function filterRequests(filter) { currentFilter = filter; loadRequests(); }

function openSolutionModal(id) {
    const r = getRequests().find(r => r.id == id);
    if (r) { 
        currentRequestId = id; 
        const problemDesc = document.getElementById('modalProblemDesc');
        if (problemDesc) problemDesc.innerHTML = `<strong>Problem:</strong><br>${escapeHtml(r.problem)}`;
        const solutionText = document.getElementById('solutionText');
        if (solutionText) solutionText.value = '';
        const modal = document.getElementById('solutionModal');
        if (modal) modal.classList.remove('hidden');
    }
}
function closeSolutionModal() { 
    const modal = document.getElementById('solutionModal');
    if (modal) modal.classList.add('hidden');
}
function submitSolution() {
    const solution = document.getElementById('solutionText');
    if (!solution || !solution.value.trim()) { alert('Enter a solution'); return; }
    let requests = getRequests();
    const idx = requests.findIndex(r => r.id == currentRequestId);
    if (idx !== -1) { 
        requests[idx].solution = solution.value; 
        requests[idx].status = 'resolved'; 
        localStorage.setItem('premiumRequests', JSON.stringify(requests)); 
        alert('Solution provided!'); 
        closeSolutionModal(); 
        loadRequests(); 
        loadDashboard(); 
    }
}
function viewSolution(id) {
    const r = getRequests().find(r => r.id == id);
    if (r && r.solution) alert(`Solution:\n\n${r.solution}`);
}

// ========== USERS ==========
function loadUsers() {
    const users = getUsers();
    const tbody = document.getElementById('usersTableBody');
    if (!tbody) return;
    
    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="no-data">No users registered yet</td></tr>';
        return;
    }
    tbody.innerHTML = users.map((u, i) => `
        <tr>
            <td>${i+1}</td>
            <td>${escapeHtml(u.fullname || 'N/A')}</td>
            <td><i class="fas fa-at"></i> ${escapeHtml(u.username)}</td>
            <td><i class="fas fa-envelope"></i> ${escapeHtml(u.email)}</td>
            <td><span class="status-badge ${u.accountType === 'premium' ? 'resolved' : 'pending'}">${u.accountType || 'free'}</span></td>
            <td>${u.registeredAt ? new Date(u.registeredAt).toLocaleDateString() : 'N/A'}</td>
            <td>${u.role !== 'admin' ? `<button class="action-btn delete" onclick="deleteUser('${u.email}')">Delete</button>` : '<span class="admin-badge">Admin</span>'}</td>
        </tr>
    `).join('');
}

function deleteUser(email) { 
    if (confirm('Delete user?')) { 
        let users = getUsers().filter(u => u.email !== email); 
        localStorage.setItem('registeredUsers', JSON.stringify(users)); 
        loadUsers(); 
        loadDashboard(); 
        alert('User deleted'); 
    } 
}

// ========== RULES ==========
function loadRules() {
    let rules = getRules();
    const container = document.getElementById('rulesList');
    if (!container) return;
    
    if (rules.length === 0) { 
        container.innerHTML = '<div class="no-data">No rules. Add one above.</div>'; 
        return; 
    }
    container.innerHTML = rules.map(r => `
        <div class="rule-item"><div class="rule-info"><div class="rule-name">${escapeHtml(r.name)} <span class="rule-severity ${r.severity}">${r.severity}</span></div>
        <div class="rule-pattern">Pattern: ${escapeHtml(r.pattern)}</div></div><button class="rule-delete" onclick="deleteRule(${r.id})"><i class="fas fa-trash"></i></button></div>
    `).join('');
}

function addSecurityRule() {
    const name = document.getElementById('ruleName');
    const pattern = document.getElementById('rulePattern');
    const severity = document.getElementById('ruleSeverity');
    const solution = document.getElementById('ruleSolution');
    
    if (!name || !pattern || !name.value || !pattern.value) { 
        alert('Fill name and pattern'); 
        return; 
    }
    let rules = getRules();
    const newId = rules.length > 0 ? Math.max(...rules.map(r => r.id)) + 1 : 1;
    rules.push({ id: newId, name: name.value, pattern: pattern.value, severity: severity ? severity.value : 'warning', solution: solution ? solution.value : '' });
    localStorage.setItem('securityRules', JSON.stringify(rules));
    if (name) name.value = '';
    if (pattern) pattern.value = '';
    if (solution) solution.value = '';
    loadRules(); 
    alert('Rule added');
}

function deleteRule(id) { 
    if (confirm('Delete rule?')) { 
        let rules = getRules().filter(r => r.id !== id); 
        localStorage.setItem('securityRules', JSON.stringify(rules)); 
        loadRules(); 
        alert('Rule deleted'); 
    } 
}

// ========== CUSTOM REQUESTS ==========
function loadCustomRequests() {
    const requests = getCustomRequests();
    const tbody = document.getElementById('customRequestsTableBody');
    if (!tbody) return;
    
    console.log('Loading custom requests, found:', requests.length);
    
    if (requests.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="no-data">No custom plan requests</td></tr>';
        return;
    }
    tbody.innerHTML = requests.map((req, index) => `
        <tr>
            <td>${index + 1}</td>
            <td>${escapeHtml(req.name || 'N/A')}</td>
            <td>${escapeHtml(req.email)}</td>
            <td>Enterprise Plan</td>
            <td>${new Date(req.requestedAt).toLocaleDateString()}</td>
            <td><span class="status-badge pending">Pending</span></td>
            <td><button class="action-btn" onclick="contactUser('${req.email}')"><i class="fas fa-envelope"></i> Contact</button></td>
        </tr>
    `).join('');
}

function contactUser(email) {
    window.location.href = `mailto:${email}`;
}

// ========== SCANS MODAL ==========
function openScansModal() {
    const scans = getScans();
    const container = document.getElementById('scansList');
    if (!container) return;
    
    if (scans.length === 0) container.innerHTML = '<div class="no-data">No scan history</div>';
    else container.innerHTML = scans.map(s => `
        <div class="scan-item"><div class="scan-file"><i class="fas fa-file-alt"></i> ${escapeHtml(s.fileName)}</div>
        <span class="scan-risk ${s.riskScore >= 70 ? 'high' : s.riskScore >= 40 ? 'medium' : 'low'}">Risk: ${s.riskScore}</span>
        <div class="scan-details"><span>Critical: ${s.failedLogins || 0}</span><span>Warnings: ${s.errors || 0}</span><span>Lines: ${s.totalLines || 0}</span></div>
        <div class="scan-date">${new Date(s.timestamp).toLocaleString()}</div></div>
    `).join('');
    const modal = document.getElementById('scansModal');
    if (modal) modal.classList.remove('hidden');
}

function closeScansModal() { 
    const modal = document.getElementById('scansModal');
    if (modal) modal.classList.add('hidden');
}

// ========== STATS CARD HELPERS ==========
function showPendingRequests() { switchToTab('requests'); currentFilter = 'pending'; loadRequests(); }
function showResolvedRequests() { switchToTab('requests'); currentFilter = 'resolved'; loadRequests(); }

// ========== HELPER ==========
function escapeHtml(text) { 
    if (!text) return ''; 
    return text.replace(/[&<>]/g, function(m) { 
        if (m === '&') return '&amp;'; 
        if (m === '<') return '&lt;'; 
        if (m === '>') return '&gt;'; 
        return m; 
    }); 
}

// ========== INITIALIZE ==========
document.addEventListener('DOMContentLoaded', function() {
    console.log('Admin page initializing...');
    if (!checkAdminAuth()) return;
    
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) { 
            e.preventDefault(); 
            switchToTab(this.getAttribute('data-tab')); 
        });
    });
    
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', function() { 
            filterRequests(this.getAttribute('data-filter')); 
        });
    });
    
    const changeMoodBtn = document.getElementById('changeMoodBtn');
    if (changeMoodBtn) {
        changeMoodBtn.addEventListener('click', () => window.location.href = '../index.html');
    }
    
    loadDashboard();
    loadRequests();
    loadRules();
    loadUsers();
    loadCustomRequests();
    
    console.log('Admin page initialized');
});

// Make functions global
window.logout = logout;
window.switchToTab = switchToTab;
window.filterRequests = filterRequests;
window.filterUsersByType = filterUsersByType;
window.openSolutionModal = openSolutionModal;
window.closeSolutionModal = closeSolutionModal;
window.submitSolution = submitSolution;
window.viewSolution = viewSolution;
window.deleteUser = deleteUser;
window.addSecurityRule = addSecurityRule;
window.deleteRule = deleteRule;
window.openScansModal = openScansModal;
window.closeScansModal = closeScansModal;
window.showPendingRequests = showPendingRequests;
window.showResolvedRequests = showResolvedRequests;
window.contactUser = contactUser;