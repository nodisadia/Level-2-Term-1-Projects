// profile.js - Profile Page

let currentUser = null;

function getUsers() {
    const stored = localStorage.getItem('registeredUsers');
    return stored ? JSON.parse(stored) : [];
}

function saveUsers(users) {
    localStorage.setItem('registeredUsers', JSON.stringify(users));
}

function getScans() {
    const stored = localStorage.getItem('scanHistory');
    return stored ? JSON.parse(stored) : [];
}

function checkAuth() {
    const user = localStorage.getItem('user');
    if (!user) {
        window.location.href = 'login.html';
        return false;
    }
    currentUser = JSON.parse(user);
    document.getElementById('userNameDisplay').innerText = currentUser.email.split('@')[0];
    return true;
}

function logout() {
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

function showMessage(message, type) {
    alert(message);
}

function loadProfileData() {
    const users = getUsers();
    const userData = users.find(u => u.email === currentUser.email);
    
    if (!userData) return;
    
    document.getElementById('profileUsername').innerText = userData.username || '--';
    document.getElementById('profileEmail').innerText = userData.email || '--';
    document.getElementById('profileProfession').innerText = userData.profession || 'Not specified';
    document.getElementById('profileAccountType').innerHTML = userData.accountType === 'premium' 
        ? '<span style="color: #ff9800;"><i class="fas fa-crown"></i> Premium</span>' 
        : '<span style="color: #4caf50;"><i class="fas fa-user"></i> Free</span>';
    document.getElementById('profileRegisteredAt').innerText = userData.registeredAt 
        ? new Date(userData.registeredAt).toLocaleDateString() 
        : 'N/A';
    
    const scans = getScans();
    const userScans = scans.filter(s => s.userId === userData.email || s.userId === userData.username);
    document.getElementById('profileTotalScans').innerText = userScans.length;
    
    document.getElementById('fullname').value = userData.fullname || '';
    document.getElementById('profession').value = userData.profession || '';
}

function updateProfile(event) {
    event.preventDefault();
    
    const newFullname = document.getElementById('fullname').value.trim();
    const newProfession = document.getElementById('profession').value;
    
    if (!newFullname) {
        alert('Please enter your full name');
        return;
    }
    
    const users = getUsers();
    const userIndex = users.findIndex(u => u.email === currentUser.email);
    
    if (userIndex !== -1) {
        users[userIndex].fullname = newFullname;
        users[userIndex].profession = newProfession;
        saveUsers(users);
        
        currentUser.name = newFullname;
        localStorage.setItem('user', JSON.stringify(currentUser));
        
        alert('Profile updated successfully!');
        loadProfileData();
    }
}

function changePassword(event) {
    event.preventDefault();
    
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    const msgDiv = document.getElementById('confirmMessage');
    
    if (!currentPassword) {
        alert('Please enter your current password');
        return;
    }
    
    const users = getUsers();
    const userIndex = users.findIndex(u => u.email === currentUser.email);
    
    if (userIndex === -1) {
        alert('User not found');
        return;
    }
    
    if (users[userIndex].password !== currentPassword) {
        alert('Current password is incorrect');
        return;
    }
    
    if (!newPassword) {
        alert('Please enter a new password');
        return;
    }
    
    if (newPassword.length < 6) {
        alert('Password must be at least 6 characters');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        msgDiv.innerHTML = 'Passwords do not match';
        msgDiv.style.color = '#f44336';
        return;
    }
    
    users[userIndex].password = newPassword;
    saveUsers(users);
    
    document.getElementById('currentPassword').value = '';
    document.getElementById('newPassword').value = '';
    document.getElementById('confirmPassword').value = '';
    msgDiv.innerHTML = 'Password changed successfully!';
    msgDiv.style.color = '#4caf50';
    
    setTimeout(() => {
        msgDiv.innerHTML = '';
    }, 3000);
}

function deleteAccount() {
    if (confirm('⚠️ WARNING: This will permanently delete your account. Are you sure?')) {
        const confirmation = prompt('Type "DELETE" to confirm:');
        if (confirmation === 'DELETE') {
            let users = getUsers();
            users = users.filter(u => u.email !== currentUser.email);
            saveUsers(users);
            
            let scans = getScans();
            scans = scans.filter(s => s.userId !== currentUser.email && s.userId !== currentUser.username);
            localStorage.setItem('scanHistory', JSON.stringify(scans));
            
            localStorage.removeItem('user');
            
            alert('Account deleted successfully');
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 1500);
        } else {
            alert('Account deletion cancelled');
        }
    }
}


function upgradePlan() {
    const currentUser = JSON.parse(localStorage.getItem('user'));
    if (currentUser && currentUser.accountType !== 'premium') {
        window.location.href = `payment.html?plan=premium&email=${encodeURIComponent(currentUser.email)}&name=${encodeURIComponent(currentUser.name || currentUser.username)}`;
    } else {
        alert('You are already on Premium plan!');
    }
}
function initProfilePage() {
    if (!checkAuth()) return;
    loadProfileData();
    
    document.getElementById('updateProfileForm').addEventListener('submit', updateProfile);
    document.getElementById('changePasswordForm').addEventListener('submit', changePassword);
    
    document.getElementById('changeMoodBtn').addEventListener('click', () => {
        window.location.href = '../index.html';
    });
}

window.logout = logout;
window.deleteAccount = deleteAccount;

document.addEventListener('DOMContentLoaded', initProfilePage);