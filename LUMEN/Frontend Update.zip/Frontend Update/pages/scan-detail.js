// scan-detail.js - Scan Detail Page

let currentScan = null;

function getScanHistory() {
    const stored = localStorage.getItem('scanHistory');
    return stored ? JSON.parse(stored) : [];
}

function checkAuth() {
    const user = localStorage.getItem('user');
    if (!user) {
        window.location.href = 'login.html';
        return false;
    }
    document.getElementById('userNameDisplay').innerText = JSON.parse(user).email.split('@')[0];
    return true;
}

function logout() {
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

function goBack() {
    window.location.href = 'history.html';
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Security Solutions
const securitySolutions = {
    'brute_force': {
        title: 'Brute Force Attack Prevention',
        command: `# Block IP after failed attempts using fail2ban
sudo apt install fail2ban -y
sudo systemctl enable fail2ban
sudo systemctl start fail2ban

# Manually ban an IP
sudo fail2ban-client set sshd banip 192.168.1.100

# Or using iptables
sudo iptables -A INPUT -s 192.168.1.100 -j DROP`
    },
    'path_traversal': {
        title: 'Path Traversal Prevention',
        command: `# Prevent directory traversal in Apache
echo 'RewriteCond %{REQUEST_URI} \\.\\./ [NC]' | sudo tee -a /etc/apache2/conf-available/security.conf
echo 'RewriteRule .* - [F]' | sudo tee -a /etc/apache2/conf-available/security.conf
sudo a2enmod rewrite
sudo systemctl restart apache2

# For Nginx:
echo 'location ~ \\.\\./ { deny all; }' | sudo tee -a /etc/nginx/sites-available/default
sudo nginx -t && sudo systemctl restart nginx`
    },
    'admin_access': {
        title: 'Admin Access Restriction',
        command: `# Restrict admin panel by IP (Nginx)
sudo tee -a /etc/nginx/sites-available/default << 'EOF'
location /admin {
    allow 192.168.1.0/24;
    deny all;
}
EOF
sudo nginx -t && sudo systemctl restart nginx`
    },
    'security_headers': {
        title: 'Security Headers Configuration',
        command: `# Add security headers (Nginx)
sudo tee -a /etc/nginx/conf.d/security-headers.conf << 'EOF'
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-XSS-Protection "1; mode=block" always;
EOF
sudo systemctl restart nginx`
    }
};

function loadScanData() {
    const urlParams = new URLSearchParams(window.location.search);
    const scanId = urlParams.get('id');
    
    if (!scanId) {
        alert('No scan ID provided');
        goBack();
        return false;
    }
    
    const scans = getScanHistory();
    currentScan = scans.find(s => s.id == scanId);
    
    if (!currentScan) {
        alert('Scan not found');
        goBack();
        return false;
    }
    
    return true;
}

function updateUI() {
    // File name and risk score
    document.getElementById('scanFileName').innerText = currentScan.fileName || 'Unknown File';
    document.getElementById('riskScore').innerText = currentScan.riskScore || 0;
    document.getElementById('totalLines').innerText = currentScan.totalLines || 0;
    document.getElementById('analysisDate').innerText = new Date(currentScan.timestamp).toLocaleString();
    
    // Risk badge
    const riskBadge = document.getElementById('riskBadge');
    let riskText = '', riskClass = '';
    if (currentScan.riskScore >= 70) {
        riskText = 'HIGH RISK';
        riskClass = 'high';
    } else if (currentScan.riskScore >= 40) {
        riskText = 'MEDIUM RISK';
        riskClass = 'medium';
    } else {
        riskText = 'LOW RISK';
        riskClass = 'low';
    }
    riskBadge.innerText = riskText;
    riskBadge.className = `risk-badge-large ${riskClass}`;
    
    // Threat counts
    const criticalCount = (currentScan.failedLogins || 0) + (currentScan.suspiciousPaths || 0) + (currentScan.adminAccess || 0);
    const warningCount = currentScan.errors || 0;
    const passedCount = Math.max(0, 10 - criticalCount - warningCount);
    
    document.getElementById('criticalCount').innerText = criticalCount;
    document.getElementById('warningCount').innerText = warningCount;
    document.getElementById('passedCount').innerText = passedCount;
    
    buildFindingsTable();
    buildCommands();
}

function buildFindingsTable() {
    const tbody = document.getElementById('findingsTableBody');
    const findings = [];
    
    if (currentScan.failedLogins > 0) {
        findings.push({
            type: 'Brute Force Attack',
            severity: 'critical',
            count: currentScan.failedLogins,
            description: `Multiple failed login attempts detected (${currentScan.failedLogins} times). Possible brute force attack.`,
            remediation: 'brute_force'
        });
    }
    
    if (currentScan.suspiciousPaths > 0) {
        findings.push({
            type: 'Path Traversal',
            severity: 'critical',
            count: currentScan.suspiciousPaths,
            description: `Suspicious path traversal patterns detected (${currentScan.suspiciousPaths} times).`,
            remediation: 'path_traversal'
        });
    }
    
    if (currentScan.adminAccess > 0) {
        findings.push({
            type: 'Unauthorized Admin Access',
            severity: 'warning',
            count: currentScan.adminAccess,
            description: `Unauthorized attempts to access admin panel (${currentScan.adminAccess} times).`,
            remediation: 'admin_access'
        });
    }
    
    if (currentScan.errors > 0) {
        findings.push({
            type: 'Server Errors',
            severity: 'warning',
            count: currentScan.errors,
            description: `${currentScan.errors} error responses detected.`,
            remediation: 'security_headers'
        });
    }
    
    if (findings.length === 0) {
        tbody.innerHTML = '<tr><td colspan="5" class="no-data">No security issues detected!</td></tr>';
        return;
    }
    
    tbody.innerHTML = findings.map(f => `
        <tr>
            <td><strong>${f.type}</strong></td>
            <td><span class="severity-badge ${f.severity}">${f.severity.toUpperCase()}</span></td>
            <td>${f.count}</td>
            <td>${f.description}</td>
            <td><button class="remediation-btn" onclick="scrollToCommand('${f.remediation}')">View Fix</button></td>
        </tr>
    `).join('');
}

function buildCommands() {
    const container = document.getElementById('commandsList');
    const commands = [];
    
    if (currentScan.failedLogins > 0) commands.push(securitySolutions.brute_force);
    if (currentScan.suspiciousPaths > 0) commands.push(securitySolutions.path_traversal);
    if (currentScan.adminAccess > 0) commands.push(securitySolutions.admin_access);
    if (currentScan.errors > 0) commands.push(securitySolutions.security_headers);
    
    if (commands.length === 0) {
        container.innerHTML = '<div class="command-card"><div class="command-body"><p>No remediation needed. Your system is secure!</p></div></div>';
        return;
    }
    
    container.innerHTML = commands.map((cmd, idx) => `
        <div class="command-card" id="cmd-${idx}">
            <div class="command-header">
                <div class="command-title"><i class="fas fa-terminal"></i> ${cmd.title}</div>
                <button class="command-copy" onclick="copyCommand(this, \`${escapeHtml(cmd.command).replace(/`/g, '\\`')}\`)">Copy Command</button>
            </div>
            <div class="command-body">
                <pre class="command-code">${escapeHtml(cmd.command)}</pre>
            </div>
        </div>
    `).join('');
}

function scrollToCommand(commandKey) {
    const commandMap = { 'brute_force': 0, 'path_traversal': 1, 'admin_access': 2, 'security_headers': 3 };
    const index = commandMap[commandKey];
    if (index !== undefined) {
        const element = document.getElementById(`cmd-${index}`);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'start' });
            element.style.boxShadow = '0 0 0 3px var(--accent)';
            setTimeout(() => { element.style.boxShadow = ''; }, 2000);
        }
    }
}

function copyCommand(button, command) {
    navigator.clipboard.writeText(command).then(() => {
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-check"></i> Copied!';
        setTimeout(() => { button.innerHTML = originalText; }, 2000);
        alert('Command copied to clipboard!');
    }).catch(() => {
        alert('Failed to copy');
    });
}

function init() {
    if (!checkAuth()) return;
    if (!loadScanData()) return;
    updateUI();
    
    document.getElementById('changeMoodBtn').addEventListener('click', () => {
        window.location.href = '../index.html';
    });
}

window.logout = logout;
window.goBack = goBack;
window.copyCommand = copyCommand;
window.scrollToCommand = scrollToCommand;

document.addEventListener('DOMContentLoaded', init);